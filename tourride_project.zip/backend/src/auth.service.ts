// auth.service.ts - serviço de autenticação
