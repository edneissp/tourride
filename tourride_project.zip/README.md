# TourRide

Aplicativo de mobilidade turística.

## Estrutura do Projeto

- **Frontend**: Flutter Web
- **Backend**: NestJS
- **Banco de Dados**: PostgreSQL

### Pasta `frontend/`

Contém a interface do usuário, com integração com as APIs e design responsivo.

### Pasta `backend/`

API RESTful criada com NestJS, autenticação com JWT e estrutura modular.

## Instruções para o Dev

1. Verificar integração entre frontend e backend.
2. Configurar variáveis de ambiente (.env).
3. Gerar o APK com Flutter para Android.
4. Cores e logo já definidos.
5. APIs estão prontas para consumo.
